#pragma once

#include "../Module.hpp"
#include <GLES2/gl2.h>
#include <string>
#include <vector>
#include <cstdint>

struct OreEntry {
    float x, y, z;   // world-space block center (x+0.5, y, z+0.5)
    float r, g, b;   // linear RGB colour
};

class OreEspModule : public Module {
public:
    OreEspModule();

    void onInit()    override;
    void onEnable()  override;
    void onDisable() override;
    void onFrame()   override;

    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    // ── User-visible settings ──────────────────────────────────────────
    int   scanRadius   = 12;      // blocks in each axis
    float lineAlpha    = 0.90f;   // wireframe opacity
    float fieldOfView  = 70.0f;   // vertical FOV degrees — match your MC slider
    bool  xray         = true;    // disable depth test → visible through terrain
    bool  showCoal     = false;
    bool  showIron     = true;
    bool  showGold     = true;
    bool  showDiamond  = true;
    bool  showEmerald  = true;
    bool  showLapis    = true;
    bool  showRedstone = true;
    bool  showCopper   = true;
    bool  showQuartz   = true;
    bool  showDebris   = true;    // ancient_debris

private:
    // ── Event subscriptions ────────────────────────────────────────────
    uint64_t m_tickSub   = 0;
    uint64_t m_camSub    = 0;

    // ── Shared state (all on MCBE main thread — no mutex needed) ──────
    std::vector<OreEntry> m_ores;
    float m_camX = 0, m_camY = 0, m_camZ = 0;
    float m_pitch = 0, m_yaw = 0;
    bool  m_hasCamera = false;
    int   m_tickCounter = 0;
    static constexpr int SCAN_EVERY = 20; // ticks between scans

    // ── Block-query function (resolved once in onInit) ─────────────────
    // BlockSource::getBlock(const BlockPos&) → const Block&  (returned by ref = ptr in x0)
    using FnGetBlock = const void*(*)(void* blockSource, const void* blockPos);
    FnGetBlock m_getBlock = nullptr;

    // ── GL resources ──────────────────────────────────────────────────
    bool   m_glReady  = false;
    GLuint m_prog     = 0;
    GLint  m_locMVP   = -1;
    GLint  m_locAlpha = -1;
    GLint  m_locPos   = -1;
    GLint  m_locColor = -1;

    // ── Helpers ───────────────────────────────────────────────────────
    bool initGL();
    void cleanupGL();
    void scanOres(void* playerActor);
    bool classifyOre(const std::string& name, float& r, float& g, float& b) const;

    // MVP reconstruction from cached pitch/yaw/camPos
    void buildMVP(float* out16, float aspect) const;
    static void mat4mul(const float* a, const float* b, float* out);

    // Appends 24 GL_LINES vertices (12 edges) for one block wireframe
    static void pushBox(std::vector<float>& verts,
                        float cx, float cy, float cz,
                        float r,  float g,  float b);
};
