#include "orespy.hpp"

#include <bedrocktools/events/ClientInstanceUpdateEvent.hpp>
#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/LocalPlayerTickEvent.hpp>
#include <bedrocktools/memory/Signatures.hpp>
#include <bedrocktools/sdk/Memory.hpp>
#include <bedrocktools/sdk/Offsets.hpp>
#include <bedrocktools/sdk/Types.hpp>
#include <bedrocktools/sdk/world/Actor.hpp>

#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include <cmath>
#include <cstring>
#include <string>
#include <vector>

using namespace bedrocktools::events;
using namespace bedrocktools::sdk;
using namespace bedrocktools::sdk::offsets;
using bedrocktools::memory::SignatureId;
using bedrocktools::memory::resolve;

// ─────────────────────────────────────────────────────────────────────────────
// Block name offset chain (all embedded structs — no extra pointer dereferences):
//   Block::mBlockType   (0x68)  → BlockLegacy*        (single pointer)
//   BlockLegacy + 0x88          → NameInfo             (embedded)
//   NameInfo    + 0x40          → HashedString mFullName (embedded)
//   HashedString + 0x08         → std::string mStr     (embedded)
// Total from BlockLegacy base: 0x88 + 0x40 + 0x08 = 0xD0
// ─────────────────────────────────────────────────────────────────────────────
static constexpr uintptr_t OFF_BLOCK_LEGACY = 0x68;
static constexpr uintptr_t OFF_LEGACY_NAME  = 0x88 + 0x40 + 0x08; // = 0xD0

// ─── GLSL sources ─────────────────────────────────────────────────────────────

static constexpr const char* kVertSrc = R"(
uniform   mat4  uMVP;
attribute vec3  aPos;
attribute vec3  aColor;
varying   vec3  vColor;
void main() {
    gl_Position = uMVP * vec4(aPos, 1.0);
    vColor = aColor;
}
)";

static constexpr const char* kFragSrc = R"(
precision mediump float;
varying vec3  vColor;
uniform float uAlpha;
void main() {
    gl_FragColor = vec4(vColor, uAlpha);
}
)";

// ─── Ctor ────────────────────────────────────────────────────────────────────

OreEspModule::OreEspModule()
    : Module("Ore ESP", "Wireframe boxes on nearby ores. Colors match each mineral.") {}

// ─── onInit: resolve block-query function once at startup ─────────────────────

void OreEspModule::onInit() {
    const uintptr_t addr = resolve(SignatureId::BlockSourceGetBlock);
    if (addr) m_getBlock = reinterpret_cast<FnGetBlock>(addr);
}

// ─── onEnable ────────────────────────────────────────────────────────────────

void OreEspModule::onEnable() {
    m_tickCounter = 0;
    m_hasCamera   = false;
    m_ores.clear();

    // ── Tick: cache rotation every tick; scan blocks every SCAN_EVERY ticks ──
    m_tickSub = bus().subscribe<LocalPlayerTickEvent>([this](LocalPlayerTickEvent& e) {
        if (!e.player) return;

        // Rotation is cheap to read every tick — keeps the view snappy.
        const uintptr_t rotComp = field<uintptr_t>(e.player, Actor::mActorRotationComponent);
        if (rotComp) {
            m_pitch = *reinterpret_cast<const float*>(rotComp + 0);
            m_yaw   = *reinterpret_cast<const float*>(rotComp + 4);
        }

        if (++m_tickCounter >= SCAN_EVERY) {
            m_tickCounter = 0;
            scanOres(e.player);
        }
    });

    // ── ClientUpdate: cache the actual render camera position (not feet pos) ──
    m_camSub = bus().subscribe<ClientInstanceUpdateEvent>([this](ClientInstanceUpdateEvent& e) {
        if (!e.clientInstance) return;
        const void* ci  = e.clientInstance;
        const void* lr  = field<void*>(ci,  ClientInstance::mLevelRenderer);
        if (!lr) return;
        const void* lrp = field<void*>(lr,  LevelRenderer::mLevelRendererPlayer);
        if (!lrp) return;
        const Vec3 cam  = field<Vec3>(lrp, LevelRendererPlayer::mCamPos);
        m_camX = cam.x; m_camY = cam.y; m_camZ = cam.z;
        m_hasCamera = true;
    });
}

// ─── onDisable ───────────────────────────────────────────────────────────────

void OreEspModule::onDisable() {
    bus().unsubscribe(m_tickSub);
    bus().unsubscribe(m_camSub);
    m_tickSub = m_camSub = 0;
    m_ores.clear();
    m_hasCamera = false;
    cleanupGL();
}

// ─── GL init (lazy, first onFrame) ───────────────────────────────────────────

static GLuint compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    return s;
}

bool OreEspModule::initGL() {
    if (m_glReady) return true;

    GLuint vert = compileShader(GL_VERTEX_SHADER,   kVertSrc);
    GLuint frag = compileShader(GL_FRAGMENT_SHADER, kFragSrc);
    m_prog = glCreateProgram();
    glAttachShader(m_prog, vert);
    glAttachShader(m_prog, frag);
    glLinkProgram(m_prog);
    glDeleteShader(vert);
    glDeleteShader(frag);

    GLint ok = 0;
    glGetProgramiv(m_prog, GL_LINK_STATUS, &ok);
    if (!ok) { glDeleteProgram(m_prog); m_prog = 0; return false; }

    m_locMVP   = glGetUniformLocation(m_prog, "uMVP");
    m_locAlpha = glGetUniformLocation(m_prog, "uAlpha");
    m_locPos   = glGetAttribLocation (m_prog, "aPos");
    m_locColor = glGetAttribLocation (m_prog, "aColor");
    m_glReady  = true;
    return true;
}

void OreEspModule::cleanupGL() {
    if (m_prog) { glDeleteProgram(m_prog); m_prog = 0; }
    m_glReady = false;
}

// ─── onFrame: runs just before EGL swapBuffers — GL context fully valid ───────

void OreEspModule::onFrame() {
    if (!m_hasCamera || m_ores.empty()) return;
    if (!initGL()) return;

    // Screen dimensions for aspect ratio
    EGLDisplay dpy = eglGetCurrentDisplay();
    EGLSurface srf = eglGetCurrentSurface(EGL_DRAW);
    if (dpy == EGL_NO_DISPLAY || srf == EGL_NO_SURFACE) return;
    EGLint w = 1, h = 1;
    eglQuerySurface(dpy, srf, EGL_WIDTH,  &w);
    eglQuerySurface(dpy, srf, EGL_HEIGHT, &h);
    if (w <= 0 || h <= 0) return;

    // Build vertex buffer: all boxes in camera-relative world space
    std::vector<float> verts;
    verts.reserve(m_ores.size() * 144); // 12 edges × 2 verts × 6 floats each
    for (const auto& ore : m_ores) {
        pushBox(verts,
            ore.x - m_camX, ore.y - m_camY, ore.z - m_camZ,
            ore.r, ore.g, ore.b);
    }
    if (verts.empty()) return;

    // MVP from reconstructed view + perspective
    float mvp[16];
    buildMVP(mvp, static_cast<float>(w) / static_cast<float>(h));

    // ── Save minimal GL state ──────────────────────────────────────────────
    GLint prevProg = 0;
    glGetIntegerv(GL_CURRENT_PROGRAM, &prevProg);
    GLboolean prevBlend  = glIsEnabled(GL_BLEND);
    GLboolean prevDepth  = glIsEnabled(GL_DEPTH_TEST);

    // ── Our depth policy: fully under our control ──────────────────────────
    if (xray) {
        glDisable(GL_DEPTH_TEST);               // visible through all terrain
    } else {
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LESS);                   // occluded by terrain normally
    }
    glDepthMask(GL_FALSE);                      // never pollute the depth buffer
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // ── Draw ──────────────────────────────────────────────────────────────
    glUseProgram(m_prog);
    glUniformMatrix4fv(m_locMVP, 1, GL_FALSE, mvp);
    glUniform1f(m_locAlpha, lineAlpha);

    // Client-side arrays — no VBO allocation for dynamic data
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    const GLsizei stride = 6 * static_cast<GLsizei>(sizeof(float));
    const auto iPos   = static_cast<GLuint>(m_locPos);
    const auto iColor = static_cast<GLuint>(m_locColor);

    glEnableVertexAttribArray(iPos);
    glEnableVertexAttribArray(iColor);
    glVertexAttribPointer(iPos,   3, GL_FLOAT, GL_FALSE, stride, verts.data());
    glVertexAttribPointer(iColor, 3, GL_FLOAT, GL_FALSE, stride, verts.data() + 3);

    glDrawArrays(GL_LINES, 0, static_cast<GLsizei>(verts.size() / 6));

    // ── Restore ────────────────────────────────────────────────────────────
    glDisableVertexAttribArray(iPos);
    glDisableVertexAttribArray(iColor);
    glUseProgram(static_cast<GLuint>(prevProg));
    glDepthMask(GL_TRUE);
    if (prevDepth)  glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (!prevBlend) glDisable(GL_BLEND);
    // Restore MC's typical depth function
    glDepthFunc(GL_LEQUAL);
}

// ─── Block scan ──────────────────────────────────────────────────────────────

void OreEspModule::scanOres(void* player) {
    if (!m_getBlock || !player) return;

    // Navigate: Actor → Dimension → BlockSource
    const uintptr_t dim = field<uintptr_t>(player, Actor::mDimension);
    if (!dim) return;
    const uintptr_t bs = *reinterpret_cast<const uintptr_t*>(dim + Dimension::mBlockSource);
    if (!bs) return;

    // Player position from StateVectorComponent
    const void* svc = field<void*>(player, Actor::mStateVectorComponent);
    if (!svc) return;
    const Vec3 pos = field<Vec3>(svc, 0);

    const int px = static_cast<int>(std::floor(pos.x));
    const int py = static_cast<int>(std::floor(pos.y));
    const int pz = static_cast<int>(std::floor(pos.z));
    const int r  = scanRadius;

    // Same struct and call pattern confirmed from debugmenu.cpp
    struct BlockPos { int x, y, z; };

    std::vector<OreEntry> found;
    found.reserve(256);

    for (int dx = -r; dx <= r; ++dx)
    for (int dy = -r; dy <= r; ++dy)
    for (int dz = -r; dz <= r; ++dz) {
        const BlockPos bp{ px + dx, py + dy, pz + dz };

        // Returns const Block& — pointer in x0
        const void* blk = m_getBlock(reinterpret_cast<void*>(bs), &bp);
        if (!blk) continue;

        // Block → BlockLegacy* (single pointer at offset 0x68)
        const void* bl = field<const void*>(blk, OFF_BLOCK_LEGACY);
        if (!bl) continue;

        // BlockLegacy + 0xD0 → std::string (embedded chain through NameInfo → HashedString)
        const auto* name = reinterpret_cast<const std::string*>(
            reinterpret_cast<uintptr_t>(bl) + OFF_LEGACY_NAME);

        // Sanity gate: valid std::string size, avoid reading garbage
        if (!name || name->empty() || name->size() > 128) continue;

        float or_ = 0, og = 0, ob = 0;
        if (!classifyOre(*name, or_, og, ob)) continue;

        // Store world-space center: x+0.5, y (feet), z+0.5
        found.push_back({
            static_cast<float>(bp.x) + 0.5f,
            static_cast<float>(bp.y),
            static_cast<float>(bp.z) + 0.5f,
            or_, og, ob
        });
    }

    m_ores = std::move(found);
}

// ─── Ore colour table ─────────────────────────────────────────────────────────
// Deepslate variants all contain the base ore keyword → same colour automatically.
// Order: most-specific substring first (ancient_debris before any single-word check).

bool OreEspModule::classifyOre(const std::string& n, float& r, float& g, float& b) const {
    auto has = [&](const char* s) { return n.find(s) != std::string::npos; };

    if (has("ancient_debris") && showDebris)  { r=0.55f; g=0.22f; b=0.18f; return true; } // deep maroon
    if (has("diamond")    && showDiamond)     { r=0.00f; g=0.87f; b=0.92f; return true; } // celeste
    if (has("emerald")    && showEmerald)     { r=0.05f; g=0.85f; b=0.25f; return true; } // emerald green
    if (has("redstone")   && showRedstone)    { r=1.00f; g=0.13f; b=0.13f; return true; } // red (covers lit_redstone too)
    if (has("lapis")      && showLapis)       { r=0.10f; g=0.24f; b=0.78f; return true; } // lapis blue
    if (has("gold")       && showGold)        { r=1.00f; g=0.84f; b=0.00f; return true; } // gold (covers nether_gold too)
    if (has("copper")     && showCopper)      { r=0.78f; g=0.39f; b=0.20f; return true; } // copper orange-brown
    if (has("iron")       && showIron)        { r=0.80f; g=0.40f; b=0.13f; return true; } // medium orange
    if (has("quartz")     && showQuartz)      { r=0.94f; g=0.90f; b=0.82f; return true; } // off-white
    if (has("coal")       && showCoal)        { r=0.20f; g=0.20f; b=0.20f; return true; } // dark gray
    return false;
}

// ─── MVP reconstruction ───────────────────────────────────────────────────────
// We reconstruct the same view-projection matrix Minecraft used to render the
// world — entirely from cached pitch/yaw/camPos + screen aspect + user FOV.
// This avoids any dependency on MC's matrix stack or RenderContext.

void OreEspModule::buildMVP(float* mvp, float aspect) const {
    static constexpr float PI = 3.14159265f;

    const float pyR = m_yaw   * (PI / 180.0f);
    const float ppR = m_pitch * (PI / 180.0f);

    // ── Forward vector (Minecraft coords: +Y up, +Z south, +X east) ──────────
    // yaw=0 → south(+Z), yaw=90 → west(-X), pitch>0 → looking down
    const float fx = -sinf(pyR) * cosf(ppR);
    const float fy = -sinf(ppR);
    const float fz =  cosf(pyR) * cosf(ppR);

    // ── Right = cross(worldUp, fwd) = (fz, 0, -fx) ───────────────────────────
    // Normalise: length = |cos(pitch)|, degenerates only at pitch=±90 (gimbal lock)
    float rx = fz, rz = -fx;
    const float rLen = sqrtf(rx * rx + rz * rz);
    if (rLen > 0.001f) { rx /= rLen; rz /= rLen; }
    else               { rx = 1.0f;  rz = 0.0f; }   // fallback: player looking straight up/down
    // ry is always 0 by construction (worldUp × fwd only touches xz plane)
    constexpr float ry = 0.0f;

    // ── Camera-up = cross(fwd, right) ────────────────────────────────────────
    const float ux =  fy * rz;           // fy*rz - fz*ry,  ry=0
    const float uy =  fz * rx - fx * rz;
    const float uz = -fy * rx;           // fx*ry - fy*rx,  ry=0

    // ── Translation terms ─────────────────────────────────────────────────────
    const float tr_r = -(rx * m_camX + ry * m_camY + rz * m_camZ);
    const float tr_u = -(ux * m_camX + uy * m_camY + uz * m_camZ);
    const float tr_f =   fx * m_camX + fy * m_camY + fz * m_camZ; // +dot: -Z convention

    // ── View matrix (column-major) ────────────────────────────────────────────
    // OpenGL camera looks in -Z; our forward maps to -Z via negation in col 2.
    //              col0   col1   col2    col3
    const float V[16] = {
         rx,   ux,  -fx,  0.0f,  // col 0
         ry,   uy,  -fy,  0.0f,  // col 1
         rz,   uz,  -fz,  0.0f,  // col 2
        tr_r, tr_u, tr_f, 1.0f   // col 3
    };

    // ── Perspective matrix (column-major) ─────────────────────────────────────
    const float fovY  = fieldOfView * (PI / 180.0f);
    const float f     = 1.0f / tanf(fovY * 0.5f);
    const float nearP = 0.05f;
    const float farP  = 512.0f;
    const float depth = nearP - farP;   // negative

    float P[16] = {};
    P[0]  = f / aspect;
    P[5]  = f;
    P[10] = (nearP + farP) / depth;    // -(far+near)/(far-near)
    P[11] = -1.0f;
    P[14] = (2.0f * nearP * farP) / depth;

    // ── MVP = P * V ───────────────────────────────────────────────────────────
    mat4mul(P, V, mvp);
}

// Column-major 4×4 multiply: out = A * B
void OreEspModule::mat4mul(const float* a, const float* b, float* out) {
    for (int col = 0; col < 4; ++col)
    for (int row = 0; row < 4; ++row) {
        float s = 0.0f;
        for (int k = 0; k < 4; ++k) s += a[k * 4 + row] * b[col * 4 + k];
        out[col * 4 + row] = s;
    }
}

// ─── Wire-box builder ─────────────────────────────────────────────────────────
// cx/cy/cz: camera-relative centre of the block.
// Block occupies [cx-0.5 .. cx+0.5] × [cy .. cy+1] × [cz-0.5 .. cz+0.5].
// Each edge = 2 vertices × 6 floats (xyz + rgb).

void OreEspModule::pushBox(std::vector<float>& v,
                            float cx, float cy, float cz,
                            float r,  float g,  float b) {
    const float x0 = cx - 0.5f, x1 = cx + 0.5f;
    const float y0 = cy,         y1 = cy + 1.0f;
    const float z0 = cz - 0.5f, z1 = cz + 0.5f;

    // Append one vertex (pos + colour)
    auto pt = [&](float px, float py, float pz) {
        v.push_back(px); v.push_back(py); v.push_back(pz);
        v.push_back(r);  v.push_back(g);  v.push_back(b);
    };

    // Bottom face (4 edges)
    pt(x0,y0,z0); pt(x1,y0,z0);
    pt(x1,y0,z0); pt(x1,y0,z1);
    pt(x1,y0,z1); pt(x0,y0,z1);
    pt(x0,y0,z1); pt(x0,y0,z0);
    // Top face (4 edges)
    pt(x0,y1,z0); pt(x1,y1,z0);
    pt(x1,y1,z0); pt(x1,y1,z1);
    pt(x1,y1,z1); pt(x0,y1,z1);
    pt(x0,y1,z1); pt(x0,y1,z0);
    // Vertical pillars (4 edges)
    pt(x0,y0,z0); pt(x0,y1,z0);
    pt(x1,y0,z0); pt(x1,y1,z0);
    pt(x1,y0,z1); pt(x1,y1,z1);
    pt(x0,y0,z1); pt(x0,y1,z1);
}

// ─── Config ───────────────────────────────────────────────────────────────────

void OreEspModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
#define L(key, field) if (j.contains(#key)) field = j[#key].get<decltype(field)>()
    L(scanRadius,   scanRadius);
    L(lineAlpha,    lineAlpha);
    L(fieldOfView,  fieldOfView);
    L(xray,         xray);
    L(showCoal,     showCoal);
    L(showIron,     showIron);
    L(showGold,     showGold);
    L(showDiamond,  showDiamond);
    L(showEmerald,  showEmerald);
    L(showLapis,    showLapis);
    L(showRedstone, showRedstone);
    L(showCopper,   showCopper);
    L(showQuartz,   showQuartz);
    L(showDebris,   showDebris);
#undef L
}

void OreEspModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["scanRadius"]   = scanRadius;
    j["lineAlpha"]    = lineAlpha;
    j["fieldOfView"]  = fieldOfView;
    j["xray"]         = xray;
    j["showCoal"]     = showCoal;
    j["showIron"]     = showIron;
    j["showGold"]     = showGold;
    j["showDiamond"]  = showDiamond;
    j["showEmerald"]  = showEmerald;
    j["showLapis"]    = showLapis;
    j["showRedstone"] = showRedstone;
    j["showCopper"]   = showCopper;
    j["showQuartz"]   = showQuartz;
    j["showDebris"]   = showDebris;
}
