#pragma once

#include "../Module.hpp"
#include <bedrocktools/sdk/world/Actor.hpp>
#include <atomic>
#include <cstdint>

// ─── internal structs matching std::vector<DistanceSortedActor> libc++ layout ──
// ActorFetchNearbyActorsSorted returns this by value (ARM64: written via x8).
// The C++ compiler handles x8 automatically when the return type is declared here.

namespace reach_internal {

struct DistanceSortedActor {
    void*  mActor;      // pointer to the Actor object
    float  mDistance;   // euclidean distance from the calling actor
    float  _pad;        // alignment padding
};

// libc++ std::vector<DistanceSortedActor> internal representation (24 bytes on ARM64).
// Since 24 > 16, AAPCS64 uses x8 (indirect result register); the compiler handles
// this transparently when the return type is declared as ActorVec here.
struct ActorVec {
    DistanceSortedActor* begin;
    DistanceSortedActor* end;
    DistanceSortedActor* endOfStorage;
};

} // namespace reach_internal

// ─────────────────────────────────────────────────────────────────────────────

class ReachExtenderModule : public Module {
public:
    ReachExtenderModule();
    ~ReachExtenderModule() override;

    void onInit()    override;
    void onEnable()  override;
    void onDisable() override;

    // Intercept raw mouse events to track left-button state before they reach
    // the game. Returns false so clicks are never consumed.
    bool onMouseEvent(int button, bool isDown) override;

    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    // ── configurable settings ──────────────────────────────────────────────

    // Maximum reach distance in blocks (should be > vanillaReach).
    float reachDistance   = 5.0f;

    // Vanilla PvP reach ceiling. Actors inside this radius are already handled
    // by the game; our module only fires on the extended zone beyond it.
    float vanillaReach    = 3.0f;

    // Half-angle of the FOV cone used for target selection (degrees).
    // Larger = more lenient about which actors count as "in front of" the player.
    float fovDegrees      = 60.0f;

    // When true, only attack players; when false, also attack mobs.
    bool  onlyPlayers     = true;

    // When true, invisible players are also eligible targets.
    bool  attackInvisible = false;

    // press mode (false, default): one attack fires per click, matching vanilla feel.
    // hold mode  (true)          : attack fires once per game tick while holding.
    bool  holdMode        = false;

private:
    // ── resolved function pointers ─────────────────────────────────────────

    using AttackFn      = bool(*)(void* gameMode, void* target, void* a2, void* a3);
    using FetchNearbyFn = reach_internal::ActorVec(*)(void* actor, void* extent, int actorType);
    using IsPlayerFn    = bool(*)(void* actor);
    using IsInvisibleFn = bool(*)(void* actor);

    AttackFn      m_attack      = nullptr;
    FetchNearbyFn m_fetchNearby = nullptr;
    IsPlayerFn    m_isPlayer    = nullptr;
    IsInvisibleFn m_isInvisible = nullptr;

    // ── cached game state ──────────────────────────────────────────────────

    // Cached from the first real AttackEvent so we can re-call the attack
    // function with the same gameMode context even outside vanilla reach.
    void* m_gameMode = nullptr;
    void* m_attackA2 = nullptr;
    void* m_attackA3 = nullptr;

    // ── input state ───────────────────────────────────────────────────────

    // true while the attack button is physically held down.
    std::atomic<bool> m_leftDown{false};

    // In press mode: true after a new click, cleared once the attack fires.
    // This ensures exactly one attack per click regardless of tick rate.
    std::atomic<bool> m_pendingClick{false};

    // ── event subscription handles ─────────────────────────────────────────

    uint64_t m_subTick   = 0;
    uint64_t m_subAttack = 0;

    // ── helpers ───────────────────────────────────────────────────────────

    void tryExtendedAttack(bedrocktools::sdk::Player* player);
};
