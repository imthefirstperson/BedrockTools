#include "reachextender.hpp"

#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/Events.hpp>
#include <bedrocktools/memory/Signatures.hpp>

#include <cmath>

// ─── constants ───────────────────────────────────────────────────────────────

namespace {

// Mouse button ID used by MCBE for the primary (attack) action.
constexpr int kMouseLeft = 1;

// Player eye height above feet position (standing, not sneaking).
constexpr float kEyeHeight = 1.62f;

// Actor chest offset above feet used as the aiming target point.
constexpr float kChestOffset = 1.0f;

// actorType = 0 → fetch all actor types; we apply our own filters afterwards.
constexpr int kActorTypeAll = 0;

} // namespace

// ─── math helpers ────────────────────────────────────────────────────────────

namespace {

// Build a unit direction vector from Bedrock pitch/yaw (degrees).
// Convention: pitch > 0 → looking down; yaw 0 → south (+Z).
void buildLookDir(float pitchDeg, float yawDeg, float out[3]) {
    constexpr float kToRad = 3.14159265f / 180.f;
    const float p = pitchDeg * kToRad;
    const float y = yawDeg   * kToRad;
    out[0] = -sinf(y) * cosf(p);   // X: east/west
    out[1] = -sinf(p);              // Y: up/down
    out[2] =  cosf(y) * cosf(p);   // Z: north/south
}

float dot3(const float a[3], const float b[3]) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

float invSqrt(float v) {
    return 1.f / sqrtf(v);
}

} // namespace

// ─── module ──────────────────────────────────────────────────────────────────

ReachExtenderModule::ReachExtenderModule()
    : Module("Reach Extender", "Attack players beyond vanilla reach distance.") {}

ReachExtenderModule::~ReachExtenderModule() = default;

// ─── onInit: resolve all function pointers once at startup ───────────────────

void ReachExtenderModule::onInit() {
    using bedrocktools::memory::SignatureId;
    using bedrocktools::memory::resolve;

    auto r = [](SignatureId id) -> void* {
        const uintptr_t addr = resolve(id);
        return addr ? reinterpret_cast<void*>(addr) : nullptr;
    };

    m_attack      = reinterpret_cast<AttackFn>     (r(SignatureId::GameModeAttack));
    m_fetchNearby = reinterpret_cast<FetchNearbyFn>(r(SignatureId::ActorFetchNearbyActorsSorted));
    m_isPlayer    = reinterpret_cast<IsPlayerFn>   (r(SignatureId::ActorIsPlayer));
    m_isInvisible = reinterpret_cast<IsInvisibleFn>(r(SignatureId::ActorIsInvisible));
}

// ─── onEnable / onDisable ─────────────────────────────────────────────────────

void ReachExtenderModule::onEnable() {
    using namespace bedrocktools::events;

    // Cache the gameMode context pointer from any real attack the game fires.
    // We don't cancel these — vanilla attacks pass through normally.
    // Priority::Early so we always capture it before other subscribers act.
    m_subAttack = bus().subscribe<AttackEvent>([this](AttackEvent& e) {
        if (e.gameMode && !m_gameMode) {
            m_gameMode = e.gameMode;
            m_attackA2 = e.argument2;
            m_attackA3 = e.argument3;
        }
    }, EventPriority::Early);

    // Run our extended-reach logic once per game tick.
    // Priority::Late so vanilla attack events for this tick have already fired.
    m_subTick = bus().subscribe<LocalPlayerTickEvent>([this](LocalPlayerTickEvent& e) {
        tryExtendedAttack(e.player);
    }, EventPriority::Late);
}

void ReachExtenderModule::onDisable() {
    auto& b = bedrocktools::events::bus();
    b.unsubscribe(m_subTick);
    b.unsubscribe(m_subAttack);
    m_subTick = m_subAttack = 0;

    m_leftDown.store(false, std::memory_order_relaxed);
    m_pendingClick.store(false, std::memory_order_relaxed);
}

// ─── onMouseEvent: track left-button state ───────────────────────────────────

bool ReachExtenderModule::onMouseEvent(int button, bool isDown) {
    if (button != kMouseLeft) return false; // we never consume events

    if (isDown) {
        m_leftDown.store(true,  std::memory_order_release);
        m_pendingClick.store(true, std::memory_order_release);
    } else {
        m_leftDown.store(false, std::memory_order_release);
        // Do NOT clear pendingClick here — let the tick handler consume it so
        // fast clicks that start+end between ticks still fire one attack.
    }

    return false; // never consume — game must receive all clicks normally
}

// ─── tryExtendedAttack: core logic called every player tick ──────────────────

void ReachExtenderModule::tryExtendedAttack(bedrocktools::sdk::Player* player) {
    // ── preconditions ──────────────────────────────────────────────────────

    if (!player)        return;
    if (!m_attack)      return;
    if (!m_fetchNearby) return;

    // Determine if we should fire this tick.
    if (holdMode) {
        // hold mode: fire every tick while button is held
        if (!m_leftDown.load(std::memory_order_acquire)) return;
    } else {
        // press mode: fire once per click (consume the pending flag)
        const bool pending = m_pendingClick.exchange(false, std::memory_order_acq_rel);
        if (!pending) return;
    }

    // We need a valid gameMode context pointer. It's populated the first time
    // the player attacks anything within vanilla reach. If they haven't done
    // that yet this session, we skip silently.
    if (!m_gameMode) return;

    // ── fetch nearby actors ────────────────────────────────────────────────

    // Extent is a Vec3 half-size of the search AABB centred on the player.
    // We search a cube large enough to cover our maximum reach distance.
    bedrocktools::sdk::Vec3 extent{ reachDistance, reachDistance, reachDistance };

    // This call returns a std::vector<DistanceSortedActor> by value.
    // ARM64 AAPCS64: the compiler writes the result through x8 automatically.
    // Results are pre-sorted nearest-first.
    reach_internal::ActorVec nearby = m_fetchNearby(player, &extent, kActorTypeAll);

    if (!nearby.begin || nearby.begin == nearby.end) {
        goto cleanup;
    }

    {
        // ── build player look direction ────────────────────────────────────

        // rotation().x = pitch degrees, rotation().y = yaw degrees
        const bedrocktools::sdk::Vec2 rot = player->rotation();
        float look[3];
        buildLookDir(rot.x, rot.y, look);

        // ── eye position (feet + eye height) ──────────────────────────────

        const bedrocktools::sdk::Vec3 pos = player->position();
        const float eye[3] = { pos.x, pos.y + kEyeHeight, pos.z };

        // Precompute the cosine threshold for the FOV cone.
        // dot(look, dirToActor) > cosHalfFov → actor is within the cone.
        const float cosHalfFov = cosf(fovDegrees * (3.14159265f / 180.f) * 0.5f);

        void* bestTarget = nullptr;
        float bestDist   = reachDistance + 1.f; // sentinel: any closer match wins

        // ── iterate sorted results ─────────────────────────────────────────

        for (const auto* entry = nearby.begin; entry != nearby.end; ++entry) {
            void* actorPtr = entry->mActor;
            if (!actorPtr) continue;

            const float dist = entry->mDistance;

            // Skip actors inside vanilla reach — the game already handles them.
            // We only attack the EXTENDED zone: (vanillaReach, reachDistance].
            if (dist <= vanillaReach) continue;
            if (dist >  reachDistance) break; // sorted nearest-first, so we can break early

            // ── optional filters ───────────────────────────────────────────

            if (onlyPlayers && m_isPlayer && !m_isPlayer(actorPtr)) continue;
            if (!attackInvisible && m_isInvisible && m_isInvisible(actorPtr)) continue;

            // ── FOV cone check ─────────────────────────────────────────────

            // Aim at the actor's chest (feet + kChestOffset) for a natural feel.
            auto* actor = reinterpret_cast<bedrocktools::sdk::Actor*>(actorPtr);
            const bedrocktools::sdk::Vec3 apos = actor->position();

            const float dx = apos.x - eye[0];
            const float dy = (apos.y + kChestOffset) - eye[1];
            const float dz = apos.z - eye[2];
            const float lenSq = dx*dx + dy*dy + dz*dz;
            if (lenSq < 1e-6f) continue; // actor is inside the player (shouldn't happen)

            const float inv = invSqrt(lenSq);
            const float dir[3] = { dx*inv, dy*inv, dz*inv };

            if (dot3(look, dir) < cosHalfFov) continue; // outside FOV cone

            // ── nearest valid target wins ──────────────────────────────────

            if (dist < bestDist) {
                bestDist   = dist;
                bestTarget = actorPtr;
            }
        }

        // ── fire the attack ────────────────────────────────────────────────

        if (bestTarget) {
            // Call with the same gameMode context and extra args as a real attack.
            // The game's own attack cooldown prevents damage spam automatically.
            m_attack(m_gameMode, bestTarget, m_attackA2, m_attackA3);
        }
    }

cleanup:
    // Free the heap allocation made by fetchNearbyActorsSorted.
    // libc++ std::vector uses ::operator new internally (backed by malloc on Android),
    // so ::operator delete is correct here.
    if (nearby.begin) {
        ::operator delete(nearby.begin);
    }
}

// ─── config ──────────────────────────────────────────────────────────────────

void ReachExtenderModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("reachDistance"))   reachDistance   = j["reachDistance"].get<float>();
    if (j.contains("vanillaReach"))    vanillaReach    = j["vanillaReach"].get<float>();
    if (j.contains("fovDegrees"))      fovDegrees      = j["fovDegrees"].get<float>();
    if (j.contains("onlyPlayers"))     onlyPlayers     = j["onlyPlayers"].get<bool>();
    if (j.contains("attackInvisible")) attackInvisible = j["attackInvisible"].get<bool>();
    if (j.contains("holdMode"))        holdMode        = j["holdMode"].get<bool>();
}

void ReachExtenderModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["reachDistance"]   = reachDistance;
    j["vanillaReach"]    = vanillaReach;
    j["fovDegrees"]      = fovDegrees;
    j["onlyPlayers"]     = onlyPlayers;
    j["attackInvisible"] = attackInvisible;
    j["holdMode"]        = holdMode;
}
